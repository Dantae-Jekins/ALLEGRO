Código da leitura de mapa.
